#!/usr/bin/env python3

# import logging
# import sys
from popper.util import Settings, parse_settings, format_program
from popper.asp import ClingoSolver
from popper.loop import learn_solution


def show_hspace(settings):
    f = lambda i, m: print(f'% program {i}\n{format_program(generate_program(m)[0])}')
    ClingoSolver.get_hspace(settings, f)

if __name__ == '__main__':
    settings = parse_settings()
    if settings.hspace:
        show_hspace(settings)
    else:
        learn_solution(settings)