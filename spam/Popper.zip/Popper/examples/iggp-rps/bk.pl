does(1,p1,scissors).
does(1,p2,stone).
does(10,p1,stone).
does(10,p2,stone).
does(11,p1,stone).
does(11,p2,paper).
does(12,p1,scissors).
does(12,p2,paper).
does(13,p1,scissors).
does(13,p2,paper).
does(15,p1,scissors).
does(15,p2,paper).
does(16,p1,scissors).
does(16,p2,stone).
does(17,p1,scissors).
does(17,p2,scissors).
does(18,p1,scissors).
does(18,p2,paper).
does(19,p1,stone).
does(19,p2,stone).
does(20,p1,scissors).
does(20,p2,paper).
does(21,p1,paper).
does(21,p2,stone).
does(22,p1,paper).
does(22,p2,paper).
does(23,p1,stone).
does(23,p2,scissors).
does(24,p1,paper).
does(24,p2,scissors).
does(25,p1,paper).
does(25,p2,stone).
does(26,p1,stone).
does(26,p2,stone).
does(27,p1,stone).
does(27,p2,stone).
does(28,p1,stone).
does(28,p2,paper).
does(29,p1,stone).
does(29,p2,paper).
does(3,p1,paper).
does(3,p2,stone).
does(30,p1,paper).
does(30,p2,scissors).
does(31,p1,scissors).
does(31,p2,stone).
does(32,p1,paper).
does(32,p2,scissors).
does(33,p1,paper).
does(33,p2,scissors).
does(34,p1,paper).
does(34,p2,stone).
does(35,p1,paper).
does(35,p2,paper).
does(36,p1,stone).
does(36,p2,paper).
does(37,p1,paper).
does(37,p2,paper).
does(38,p1,stone).
does(38,p2,paper).
does(39,p1,paper).
does(39,p2,scissors).
does(4,p1,scissors).
does(4,p2,paper).
does(40,p1,scissors).
does(40,p2,scissors).
does(41,p1,scissors).
does(41,p2,scissors).
does(42,p1,paper).
does(42,p2,scissors).
does(43,p1,stone).
does(43,p2,paper).
does(44,p1,paper).
does(44,p2,paper).
does(45,p1,scissors).
does(45,p2,paper).
does(46,p1,stone).
does(46,p2,paper).
does(47,p1,stone).
does(47,p2,stone).
does(48,p1,stone).
does(48,p2,paper).
does(49,p1,scissors).
does(49,p2,stone).
does(50,p1,stone).
does(50,p2,scissors).
does(51,p1,paper).
does(51,p2,stone).
does(52,p1,stone).
does(52,p2,scissors).
does(53,p1,scissors).
does(53,p2,scissors).
does(54,p1,scissors).
does(54,p2,stone).
does(55,p1,paper).
does(55,p2,paper).
does(56,p1,scissors).
does(56,p2,scissors).
does(57,p1,scissors).
does(57,p2,scissors).
does(58,p1,stone).
does(58,p2,scissors).
does(6,p1,stone).
does(6,p2,stone).
does(7,p1,stone).
does(7,p2,stone).
does(9,p1,scissors).
does(9,p2,scissors).


my_succ(0,1).
my_succ(1,2).
my_succ(2,3).

my_true_score(1,p1,0).
my_true_score(1,p2,0).
my_true_score(10,p1,1).
my_true_score(10,p2,0).
my_true_score(11,p1,0).
my_true_score(11,p2,0).
my_true_score(12,p1,1).
my_true_score(12,p2,1).
my_true_score(13,p1,1).
my_true_score(13,p2,0).
my_true_score(14,p1,0).
my_true_score(14,p2,0).
my_true_score(15,p1,0).
my_true_score(15,p2,0).
my_true_score(16,p1,0).
my_true_score(16,p2,0).
my_true_score(17,p1,0).
my_true_score(17,p2,0).
my_true_score(18,p1,0).
my_true_score(18,p2,2).
my_true_score(19,p1,0).
my_true_score(19,p2,0).
my_true_score(2,p1,1).
my_true_score(2,p2,2).
my_true_score(20,p1,0).
my_true_score(20,p2,0).
my_true_score(21,p1,0).
my_true_score(21,p2,0).
my_true_score(22,p1,1).
my_true_score(22,p2,1).
my_true_score(23,p1,0).
my_true_score(23,p2,1).
my_true_score(24,p1,1).
my_true_score(24,p2,0).
my_true_score(25,p1,0).
my_true_score(25,p2,0).
my_true_score(26,p1,0).
my_true_score(26,p2,1).
my_true_score(27,p1,0).
my_true_score(27,p2,0).
my_true_score(28,p1,1).
my_true_score(28,p2,1).
my_true_score(29,p1,0).
my_true_score(29,p2,0).
my_true_score(3,p1,1).
my_true_score(3,p2,0).
my_true_score(30,p1,0).
my_true_score(30,p2,1).
my_true_score(31,p1,1).
my_true_score(31,p2,1).
my_true_score(32,p1,0).
my_true_score(32,p2,0).
my_true_score(33,p1,0).
my_true_score(33,p2,0).
my_true_score(34,p1,0).
my_true_score(34,p2,1).
my_true_score(35,p1,2).
my_true_score(35,p2,0).
my_true_score(36,p1,1).
my_true_score(36,p2,0).
my_true_score(37,p1,0).
my_true_score(37,p2,0).
my_true_score(38,p1,2).
my_true_score(38,p2,0).
my_true_score(39,p1,1).
my_true_score(39,p2,0).
my_true_score(4,p1,2).
my_true_score(4,p2,0).
my_true_score(40,p1,0).
my_true_score(40,p2,0).
my_true_score(41,p1,0).
my_true_score(41,p2,1).
my_true_score(42,p1,2).
my_true_score(42,p2,0).
my_true_score(43,p1,0).
my_true_score(43,p2,1).
my_true_score(44,p1,1).
my_true_score(44,p2,0).
my_true_score(45,p1,1).
my_true_score(45,p2,0).
my_true_score(46,p1,0).
my_true_score(46,p2,2).
my_true_score(47,p1,1).
my_true_score(47,p2,1).
my_true_score(48,p1,0).
my_true_score(48,p2,0).
my_true_score(49,p1,0).
my_true_score(49,p2,2).
my_true_score(5,p1,0).
my_true_score(5,p2,2).
my_true_score(50,p1,0).
my_true_score(50,p2,0).
my_true_score(51,p1,0).
my_true_score(51,p2,0).
my_true_score(52,p1,1).
my_true_score(52,p2,0).
my_true_score(53,p1,1).
my_true_score(53,p2,0).
my_true_score(54,p1,0).
my_true_score(54,p2,1).
my_true_score(55,p1,1).
my_true_score(55,p2,0).
my_true_score(56,p1,2).
my_true_score(56,p2,0).
my_true_score(57,p1,1).
my_true_score(57,p2,0).
my_true_score(58,p1,0).
my_true_score(58,p2,2).
my_true_score(6,p1,0).
my_true_score(6,p2,0).
my_true_score(7,p1,1).
my_true_score(7,p2,0).
my_true_score(8,p1,1).
my_true_score(8,p2,1).
my_true_score(9,p1,0).
my_true_score(9,p2,2).
my_true_step(1,1).
my_true_step(10,1).
my_true_step(11,0).
my_true_step(12,2).
my_true_step(13,2).
my_true_step(14,3).
my_true_step(15,2).
my_true_step(16,0).
my_true_step(17,1).
my_true_step(18,2).
my_true_step(19,2).
my_true_step(2,3).
my_true_step(20,0).
my_true_step(21,1).
my_true_step(22,2).
my_true_step(23,1).
my_true_step(24,2).
my_true_step(25,0).
my_true_step(26,1).
my_true_step(27,0).
my_true_step(28,2).
my_true_step(29,1).
my_true_step(3,2).
my_true_step(30,1).
my_true_step(31,2).
my_true_step(32,2).
my_true_step(33,0).
my_true_step(34,1).
my_true_step(35,2).
my_true_step(36,1).
my_true_step(37,1).
my_true_step(38,2).
my_true_step(39,1).
my_true_step(4,2).
my_true_step(40,0).
my_true_step(41,2).
my_true_step(42,2).
my_true_step(43,2).
my_true_step(44,1).
my_true_step(45,1).
my_true_step(46,2).
my_true_step(47,2).
my_true_step(48,2).
my_true_step(49,2).
my_true_step(5,3).
my_true_step(50,0).
my_true_step(51,2).
my_true_step(52,2).
my_true_step(53,2).
my_true_step(54,1).
my_true_step(55,2).
my_true_step(56,2).
my_true_step(57,1).
my_true_step(58,2).
my_true_step(6,1).
my_true_step(7,2).
my_true_step(8,3).
my_true_step(9,2).

beats(paper,stone).
beats(scissors,paper).
beats(stone,scissors).

different(p1,p2).
different(p2,p1).

c_p1(p1).
c_p2(p2).

player(p1).
player(p2).

action(paper).
action(scissors).
action(stone).

draws(E,A):-
    does(E,A,B),
    does(E,C,B),
    A \= C.

wins(E,A):-
    does(E,A,B),
    does(E,C,D),
    beats(B,D),
    player(C).

loses(E,A):-
    does(E,A,B),
    does(E,C,D),
    beats(D,B),
    player(C).


%% ========== SUPER EASY ==========
%% 10 LITERALS
%% 3 BODY LITERALS
%% 3 VARS

%% next_score(A,B):-
%%     true_score(A,B),
%%     draws(A).

%% next_score(A,B):-
%%     true_score(A,B),
%%     looses(A).

%% next_score(A,B):-
%%     true_score(A,C),
%%     succ(C,B),
%%     wins(A).

%% ========== MEDIUM ==========
%% 13 LITERALS
%% 4 BODY LITERALS
%% 4 VARS

%% next_score(A,B):-
%%     true_score(A,B),
%%     does(A,C),
%%     does(D,C),
%%     different(A,D).

%% next_score(A,B):-
%%     true_score(A,B),
%%     wins(C),
%%     different(A,C).

%% next_score(A,B):-
%%     true_score(A,C),
%%     succ(C,B),
%%     wins(A).


%% ==================================================

%% HARD
%% 18 LITERALS
%% 6 BODY LITERALS
%% 7 VARS
%% DRAWS
%% next_score(A,B):-
%%     true_score(A,B),
%%     does(A,C),
%%     does(D,C),
%%     different(A,D).

%% LOSES
%% next_score(A,B):-
%%     true_score(A,B),
%%     does(A,C),
%%     beats(D,C),
%%     does(E,D),
%%     different(A,E).

%% WINS
%% next_score(A,B):-
%%     true_score(A,C),
%%     succ(C,B),
%%     does(A,D),
%%     does(E,F),
%%     beats(D,F),
%%     different(A,E).

%% ==================================================
%% %% WITH PI
%% 18 LITERALS
%% 4 BODY LITERALS
%% 5 VARS

%% %% DRAWS
%% wins(A):-
%%     does(A,B),
%%     does(C,D),
%%     beats(B,D),
%%     player(C).

%% next_score(A,B):-
%%     true_score(A,B),
%%     does(A,B),
%%     does(C,B),
%%     different(A,C).

%% next_score(A,B):-
%%     true_score(A,B),
%%     wins(C),
%%     different(A,C).

%% next_score(A,B):-
%%     true_score(A,C),
%%     succ(C,B),
%%     wins(A).
