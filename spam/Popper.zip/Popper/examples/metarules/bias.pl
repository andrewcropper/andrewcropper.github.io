%% python3 popper.py examples/metarules
%% f(A,B):- inv1(C,B),inv1(A,C).
%% inv1(A,B):- inv2(A,C),right(C,B).
%% inv2(A,B):- right(A,C),right(C,B).
%% 1.39s user 0.07s system 99% cpu 1.463 total

max_vars(3).
max_body(2).
max_clauses(4).
enable_pi.

%% c1: target(A,B) :- p(A,C),inv2(C,B).
%% c2: target(A,B) :- q(A,C),inv1(C,B).
%% c3: inv1(A,B) :- s(A,B).
%% c4: inv2(A,B) :- r(A,B).


:- not invented(inv2,_).
:-
    invented(inv3,_).

head_pred(f,2).
%% body_pred(up,2).
%% body_pred(down,2).
body_pred(left,2).
body_pred(right,2).

%% P(A,B):-Q(A,C),R(C,B).

meta_clause(C):-
    head_literal(C,P,2,(0,1)),
    body_literal(C,Q,2,(0,1)),
    meta_lower(P,Q),
    body_size(C,1),
    not invented(Q,_),
    invented(P,_).

meta_clause(C):-
    head_literal(C,P,2,(0,1)),
    body_literal(C,Q,2,(0,2)),
    body_literal(C,R,2,(2,1)),
    meta_lower(P,Q),
    meta_lower(P,R),
    body_size(C,2),
    Q = left,
    not invented(Q,_),
    invented(R,_),
    not invented(P,_).
:-
    clause(C),
    not meta_clause(C).

meta_lower(P,Q):-
    lower(P,Q).
meta_lower(P,Q):-
    head_aux(P,_),
    body_pred(Q,_),
    not head_aux(Q,_).