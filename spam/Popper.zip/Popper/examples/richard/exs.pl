%% pos(f(2)).
%% pos(f(4)).
%% pos(f(6)).
%% pos(f(8)).
%% neg(f(1)).
%% neg(f(3)).
%% neg(f(5)).
%% neg(f(7)).
%% neg(f(9)).



%% neg(f(2)).
%% neg(f(4)).
%% neg(f(6)).
%% neg(f(8)).
%% pos(f(1)).
%% pos(f(3)).
%% pos(f(5)).
%% pos(f(7)).


neg(f(0)).
neg(f(1)).
neg(f(2)).
neg(f(3)).
neg(f(4)).
neg(f(5)).
pos(f(6)).
neg(f(7)).
neg(f(8)).
neg(f(9)).