%% 6 = 5
%% 7 = 6
%% 8 = 7
max_vars(7).
max_body(7).
max_clauses(1).
%% enable_recursion.
%% enable_pi.

head_pred(f,1).
body_pred(succ,2).
body_pred(zero,1).


%% functional(succ,2).
%% anti_symmetric(succ,2).
%% irreflexive(succ,2).

%% direction(f,)

%% direction(f,(in,out)).
%% direction(head,(in,out)).
%% direction(tail,(in,out)).
%% direction(succ,(in,out)).
%% direction(empty,(in,)).
%% direction(zero,(out,)).
%% direction(one,(out,)).