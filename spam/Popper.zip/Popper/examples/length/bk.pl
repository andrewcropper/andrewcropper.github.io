tail([_|T],T).
head([H|_],H).
empty([]).
zero(0).
one(1).